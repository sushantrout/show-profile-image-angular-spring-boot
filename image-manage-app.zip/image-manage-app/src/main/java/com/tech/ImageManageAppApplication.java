package com.tech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageManageAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImageManageAppApplication.class, args);
	}

}
